<template>
  <CurrentDayCard></CurrentDayCard>
</template>
<script>
import CurrentDayCard from '../components/CurrentDay/CurrentDayCard';
export default {
  name: 'CurrentDay',
  components: {
    CurrentDayCard,
  },
};
</script>
