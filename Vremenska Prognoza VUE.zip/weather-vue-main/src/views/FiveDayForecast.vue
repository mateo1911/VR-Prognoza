<template>
  <FiveDayCard></FiveDayCard>
</template>
<script>
import FiveDayCard from '../components/FiveDay/FiveDayCard';
export default {
  name: 'FiveDayForecast',
  components: {
    FiveDayCard,
  },
};
</script>
